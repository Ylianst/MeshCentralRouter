To customize the MeshCentral Router for Windows, create a "customization" folder in the
location of the MeshCentral Router executable and place these files in this new folder.
You can them edit the images and "customize.txt" file as needed. Note that if an image
is missing or a line in the "customize.txt" file is left blank, the default is used.